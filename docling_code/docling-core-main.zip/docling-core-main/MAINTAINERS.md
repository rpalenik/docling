# MAINTAINERS

- Cesar Berrospi Ramis - [@ceberam](https://github.com/ceberam)
- Michele Dolfi - [@dolfim-ibm](https://github.com/dolfim-ibm)
- Christoph Auer - [@cau-git](https://github.com/cau-git)
- Panos Vagenas - [@vagenas](https://github.com/vagenas)
- Peter Staar - [@PeterStaar-IBM](https://github.com/PeterStaar-IBM)

Maintainers can be contacted at [deepsearch-core@zurich.ibm.com](mailto:deepsearch-core@zurich.ibm.com).