item of leading list

# Title of the Document

Author 1
Affiliation 1

Author 2
Affiliation 2

## 1. Introduction

This paper introduces the biggest invention ever made. ...

list item 1
list item 2
list item 3
    list item 3.a
    list item 3.b
    list item 3.c
        list item 3.c.i
list item 4

This is the caption of table 1.

| Product   |   Years |   Years |
|-----------|---------|---------|
| Product   |    2016 |    2017 |
| Apple     |   49823 |  695944 |

This is the caption of figure 1.

<!-- image -->

This is the caption of figure 2.

<!-- image -->

item 1 of list

item 1 of list after empty list
item 2 of list after empty list

item 1 of neighboring list
item 2 of neighboring list
    item 1 of sub list
    Here a code snippet: `print("Hello world")` (to be displayed inline)
    Here a formula: $E=mc^2$ (to be displayed inline)

Here a code block:

```
print("Hello world")
```

Here a formula block:

$$E=mc^2$$

<!-- missing-key-value-item -->

<!-- missing-form-item -->

Some formatting chops: **bold** *italic* underline ~~strikethrough~~ subscript superscript [hyperlink](.) &amp; [~~***everything at the same time.***~~](https://github.com/DS4SD/docling)

(i) Item 1 in A
(ii) Item 2 in A
(iii) Item 3 in A
    Item 1 in B
    42. Item 2 in B
        Item 1 in C
        Item 2 in C
    Item 3 in B
(iv) Item 4 in A

List item without parent list group

The end.
