This is some introductory text.

[My Corp Test 1] custom field value 1

Regarding foo...

1. lorem
2. ipsum

Regarding bar...