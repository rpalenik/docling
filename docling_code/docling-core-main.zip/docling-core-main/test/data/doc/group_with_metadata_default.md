This document talks about various topics.

This chapter discusses foo and bar.

This is some introductory text.

This section talks about foo.

custom field value 1

This paragraph provides more details about foo.

Regarding foo...

Here some foo specifics are listed.

1. lorem
2. ipsum

This section talks about bar.

custom field value 2

Regarding bar...