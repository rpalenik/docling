# Rich tables

| cell 0,0                                               | cell 0,1                                                                                                                                                                         |
|--------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| cell 1,0                                               | *text in italic*                                                                                                                                                                 |
| - list item 1 - list item 2                            | cell 2,1                                                                                                                                                                         |
| cell 3,0                                               | | inner cell 0,0   | inner cell 0,1   | inner cell 0,2   | |------------------|------------------|------------------| | inner cell 1,0   | inner cell 1,1   | inner cell 1,2   | |
| Some text in a generic group.  More text in the group. | cell 4,1                                                                                                                                                                         |
