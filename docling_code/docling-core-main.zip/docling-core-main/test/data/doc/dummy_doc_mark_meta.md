# DocLayNet: A Large Human-Annotated Dataset for Document-Layout Analysis

[Description] ...

[Classification] Bar chart

[Molecule] CC1=NNC(C2=CN3C=CN=C3C(CC3=CC(F)=CC(F)=C3)=N2)=N1

[Docling Legacy Misc] {'myanalysis': {'prediction': 'abc'}, 'something_else': {'text': 'aaa'}}

Figure 1: Four examples of complex page layouts across different document categories

<!-- image -->

[Description] A description annotation for this table.

[Docling Legacy Misc] {'foo': 'bar'}