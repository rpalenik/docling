This is some introductory text.

Regarding foo...

1. lorem
2. ipsum

[My Corp Test 2] custom field value 2

Regarding bar...