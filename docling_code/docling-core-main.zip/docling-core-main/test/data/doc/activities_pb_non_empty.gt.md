## Summer activities

## Swimming in the lake

Duck

Figure 1: This is a cute duckling

## Let's swim!

To get started with swimming, first lay down in a water and try not to drown:

- ∞ You can relax and look around
- ∞ Paddle about
- ∞ Enjoy summer warmth

Also, don't forget:

- 1. Wear sunglasses
- 2. Don't forget to drink water
- 3. Use sun cream

Hmm, what else…

- -Another activity item
<!-- page-break -->
- -Yet another one
- -Stopping it here

Some text.

<!-- page-break -->

- -Starting the next page with a list item.
- -Second item.
