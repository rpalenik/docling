[#/body] [GroupItem:unspecified] This document talks about various topics.

  [#/groups/0] [GroupItem:chapter] This chapter discusses foo and bar.

    [#/groups/1] [GroupItem:section] This section talks about foo.

      [#/texts/1] [TextItem:text] This paragraph provides more details about foo.

      [#/groups/2] [ListGroup:list] Here some foo specifics are listed.

    [#/groups/3] [GroupItem:section] This section talks about bar.