[Summary] This document talks about various topics.

[Summary] This chapter discusses foo and bar.

[Summary] This section talks about foo.

[My Corp Test 1] custom field value 1

[Summary] This paragraph provides more details about foo.

[Summary] Here some foo specifics are listed.

[Summary] This section talks about bar.

[My Corp Test 2] custom field value 2