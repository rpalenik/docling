# Sample Markdown File

This is a sample markdown file for testing repository chunking.

## Code Example

Here's some Python code:

```python
def hello():
    print("Hello, World!")
```

## Features

- Lists
- **Bold text**
- *Italic text*
- [Links](https://example.com)

## Conclusion

This file should be processed as text content, not as code.
